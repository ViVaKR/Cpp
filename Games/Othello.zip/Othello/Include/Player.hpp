#ifndef PLAYER_HPP
#define PLAYER_HPP
enum class Player
{
    NONE = 0,
    USER = 1,
    COMPUTER = 2
};
#endif
