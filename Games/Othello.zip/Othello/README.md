# Othello

```bash

    # run (in `Othello` Folder.. )
    make clean && make && ./bin/Othello

```
