#! /usr/bin/env zsh

make clean && make
./bin/Othello
